var $= function(id) {
    return document.getElementById(id);
};

var matchPasswordForm = function () {
   var passwordOne = $("password").value;
   var passwordTwo = $("repPassword").value;
    //alert ("Password one is " + passwordOne);
    //alert ("Password two is " + passwordTwo);
    
    
    if (passwordOne !== passwordTwo) {
    alert ("Please enter matching passwords.");
    $(password).value = "";
    $(repPassword).value = "";
    
}//if
else {
    return true;
}
};

var validateEmail = function() {
    var inputText = $("email").value;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(inputText.match(mailformat)) {
        return true;
    }
    else
    {
        alert ("You have entered an invalid email address");
    }
};

var clearFields = function () {
    $("title").value = "";
    $("firstName").value = "";
    $("MI").value = "";
    $("lastName").value = "";
    $("email").value = "";
    $("phone").value = "";
    $("streetOne").value = "";
    $("streetTwo").value = "";
    $("city").value = "";
    $("state").value = "";
    $("zip").value = "";
    $("userName").value = "";
    $("password").value = "";
    $("repPassword").value = "";
    document.getElementById("source").reset();
    $("checkbox").value = "";
    $("comments").value = "";
    location.reload();
}

var runChecks = function () {
    matchPasswordForm();
    validateEmail();
    if (matchPasswordForm()==true&&validateEmail()==true){
        alert ("Thank you for registering!");
        clearFields();
    }
    
};

 window.onload = function() {
  
  $("register").onclick = runChecks;
    $("reset").onclick = clearFields; 
      
};